package com.demo.adyen.demo.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adyen.Client;
import com.adyen.enums.Environment;
import com.adyen.model.Amount;
import com.adyen.model.checkout.PaymentMethodsRequest;
import com.adyen.model.checkout.PaymentMethodsResponse;
import com.adyen.service.Checkout;
import com.adyen.service.exception.ApiException;

@RestController
public class DemoController {
	
	@Value("${API_Key}")
	String apikey; 
	
	@Value("${Merchant_Account}")
	String merchant_account; 
	
    @RequestMapping("/paymentMethods")
    public ResponseEntity<?> demo() {
    	
    	
    	// Set your X-API-KEY with the API key from the Customer Area.
    	Client client = new Client(apikey,Environment.TEST);
    
    	PaymentMethodsResponse response=null;
    	
    	try {	
    	
    	Checkout checkout = new Checkout(client);
    	PaymentMethodsRequest paymentMethodsRequest = new PaymentMethodsRequest();
    	paymentMethodsRequest.setMerchantAccount(merchant_account);
    	paymentMethodsRequest.setCountryCode("NL");
    	Amount amount = new Amount();
    	amount.setCurrency("EUR");
    	amount.setValue(1000L);
    	paymentMethodsRequest.setAmount(amount);
    	paymentMethodsRequest.setChannel(PaymentMethodsRequest.ChannelEnum.WEB);
    	
		response = checkout.paymentMethods(paymentMethodsRequest);
			
			
			
		} catch (ApiException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	 catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		 return new ResponseEntity<>(
	   		      response ,HttpStatus.OK);
    	
    }
    
    
    
    
    
    

}

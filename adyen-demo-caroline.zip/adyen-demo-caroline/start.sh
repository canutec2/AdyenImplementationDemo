./server/php/start.sh
